import java.io.IOException;
import java.util.*;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.util.*; 
import org.apache.hadoop.mapreduce.*;
import  org.apache.hadoop.mapreduce.lib.input.*;
import  org.apache.hadoop.mapreduce.lib.output.*;
public class Reduce  extends Reducer<Text, IntWritable, Text, IntWritable>
{
	private static  Map<String, String>  IsExisting = new HashMap<String,String>();
	public void reduce(Text key, Iterable<Text> values, Context contxt )throws IOException, InterruptedException
	{
		for (Text value : values)
		{
			if(Map[key.toString()])
		}
	}
}
